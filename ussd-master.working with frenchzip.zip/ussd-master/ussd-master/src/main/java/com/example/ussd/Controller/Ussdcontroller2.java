package com.example.ussd.Controller;
import com.example.ussd.Model.Userz;
import com.example.ussd.Model.UssdRequest;
import com.example.ussd.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@RestController
public class Ussdcontroller2 {

    private enum RegistrationStep {
        FIRST_NAME,
        LAST_NAME,
        NATIONAL_ID,
        LOCATION,
        CONFIRMATION,
        END
    }

    @Autowired
    private UserRepository userRepository; // Import your UserRepository class here

    @PostMapping("/ussd")
    public String processUssdRequest(@RequestBody UssdRequest ussdRequest, HttpServletRequest request) {
        HttpSession httpSession = request.getSession();
        String sessionId = ussdRequest.getSessionId();
        String text = ussdRequest.getText();
        String response = "";

        boolean newSession = sessionId.equals("1");

        if (newSession || text.equals("")) {
            httpSession.invalidate();
            httpSession = request.getSession(true);

            // Start the session with a menu for language selection
            response = "CON Select your preferred language:\n";
            response += "1. English\n";
            response += "2. French";
        } else {
            RegistrationStep currentStep = (RegistrationStep) httpSession.getAttribute("currentStep");
            Integer level = (Integer) httpSession.getAttribute("level");
            int currentLevel = (level != null) ? level.intValue() : 1;

            if (currentStep == null) {
                httpSession.setAttribute("currentStep", RegistrationStep.FIRST_NAME);
                httpSession.setAttribute("level", 1);
                currentStep = RegistrationStep.FIRST_NAME;
                currentLevel = 1;
            }

            String language = (String) httpSession.getAttribute("language");

            switch (currentStep) {
                case FIRST_NAME:
                    if (text.equalsIgnoreCase("1")) {
                        language = "English";
                        httpSession.setAttribute("language", language);
                        httpSession.setAttribute("currentStep", RegistrationStep.FIRST_NAME); // Stay in the same step
                        response = "CON Please enter your First Name:";
                    } else if (text.equalsIgnoreCase("2")) {
                        language = "French";
                        httpSession.setAttribute("language", language);
                        httpSession.setAttribute("currentStep", RegistrationStep.FIRST_NAME); // Stay in the same step
                        response = "CON Veuillez entrer votre prénom:";
                    } else {
                        // Assume the input is the user's first name
                        httpSession.setAttribute("firstName", text); // Store the user's first name
                        httpSession.setAttribute("currentStep", RegistrationStep.LAST_NAME);
                        response = language.equalsIgnoreCase("French")
                                ? "CON Veuillez entrer votre nom de famille:"
                                : "CON Please enter your Last Name:";
                    }
                    break;
                case LAST_NAME:
                    httpSession.setAttribute("lastName", text);
                    // Move to the next step (asking for National ID)
                    httpSession.setAttribute("currentStep", RegistrationStep.NATIONAL_ID);
                    response = language.equalsIgnoreCase("French")
                            ? "CON Veuillez entrer votre numéro d'identification nationale:"
                            : "CON Please enter your National ID:";
                    break;
                case NATIONAL_ID:
                    // Your national ID registration logic here
                    // Move to the next step (asking for Location)
                    httpSession.setAttribute("nationalId", text);
                    httpSession.setAttribute("currentStep", RegistrationStep.LOCATION);
                    response = language.equalsIgnoreCase("French")
                            ? "CON Veuillez entrer votre emplacement:"
                            : "CON Please enter your Location:";
                    break;
                case LOCATION:
                    // Your location registration logic here
                    // Move to the next step (asking for confirmation)
                    httpSession.setAttribute("location", text);
                    httpSession.setAttribute("currentStep", RegistrationStep.CONFIRMATION);
                    response = language.equalsIgnoreCase("French")
                            ? "CON Veuillez confirmer vos informations:\n"
                            + "Prénom: " + httpSession.getAttribute("firstName") + "\n"
                            + "Nom de famille: " + httpSession.getAttribute("lastName") + "\n"
                            + "Numéro d'identification nationale: " + httpSession.getAttribute("nationalId") + "\n"
                            + "Emplacement: " + text + "\n"
                            + "Répondez avec 1 pour confirmer ou 2 pour annuler."
                            : "CON Confirm your information:\n"
                            + "First Name: " + httpSession.getAttribute("firstName") + "\n"
                            + "Last Name: " + httpSession.getAttribute("lastName") + "\n"
                            + "National ID: " + httpSession.getAttribute("nationalId") + "\n"
                            + "Location: " + text + "\n"
                            + "Reply with 1 to confirm or 2 to cancel.";
                    break;
                case CONFIRMATION:
                    // Your confirmation logic here
                    if (text.equals("1")) {
                        // Save the user information to the database (Userz)
                        Userz newUser = new Userz();
                        newUser.setFirstName((String) httpSession.getAttribute("firstName"));
                        newUser.setLastName((String) httpSession.getAttribute("lastName"));
                        newUser.setNationalId((String) httpSession.getAttribute("nationalId"));
                        newUser.setLocation((String) httpSession.getAttribute("location"));
                        userRepository.save(newUser);

                        // Clear the session after successful registration
                        httpSession.removeAttribute("currentStep");
                        httpSession.removeAttribute("language");
                        httpSession.removeAttribute("firstName");
                        httpSession.removeAttribute("lastName");
                        httpSession.removeAttribute("nationalId");
                        httpSession.removeAttribute("location");

                        response = language.equalsIgnoreCase("French")
                                ? "END Inscription terminée. Vos informations ont été enregistrées."
                                : "END Registration completed. Your information has been saved.";
                    } else if (text.equals("2")) {
                        // If the user cancels, end the session
                        httpSession.setAttribute("currentStep", RegistrationStep.END);
                        response = language.equalsIgnoreCase("French")
                                ? "END Inscription annulée."
                                : "END Registration canceled.";
                    } else {
                        // If the user enters an invalid response, prompt again for confirmation
                        response = language.equalsIgnoreCase("French")
                                ? "CON Réponse invalide. Répondez avec 1 pour confirmer ou 2 pour annuler."
                                : " Invalid input. Reply with 1 to confirm or 2 to cancel.";
                    }
                    break;
                case END:
                    response = language.equalsIgnoreCase("French")
                            ? "END Merci de vous être inscrit !"
                            : "END Thank you for registering!";
                    break;
            }

            // Update the user's level in the session for the next interaction
            currentLevel++;
            httpSession.setAttribute("level", currentLevel);
        }

        return response;
    }
}
