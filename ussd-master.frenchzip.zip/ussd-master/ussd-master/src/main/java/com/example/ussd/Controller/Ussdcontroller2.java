package com.example.ussd.Controller;
import com.example.ussd.Model.UssdRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@RestController
public class Ussdcontroller2 {

    private enum RegistrationStep {
        LANGUAGE_SELECTION,
        FIRST_NAME,
        LAST_NAME,
        NATIONAL_ID,
        LOCATION,
        CONFIRMATION,
        END
    }

    @PostMapping("/ussd")
    public String processUssdRequest(@RequestBody UssdRequest ussdRequest, HttpServletRequest request) {
        HttpSession httpSession = request.getSession();
        String sessionId = ussdRequest.getSessionId();
        String text = ussdRequest.getText();
        String response = "";

        boolean newSession = sessionId.equals("1");

        if (newSession || text.equals("newrequest 1")) {
            httpSession.invalidate();
            httpSession = request.getSession(true);
            httpSession.setAttribute("currentStep", RegistrationStep.LANGUAGE_SELECTION);
            httpSession.setAttribute("level", 1);

            // Start the session with a menu for language selection
            response = "CON Select your preferred language:\n";
            response += "1. English\n";
            response += "2. French";
        } else {
            RegistrationStep currentStep = (RegistrationStep) httpSession.getAttribute("currentStep");
            Integer level = (Integer) httpSession.getAttribute("level");
            int currentLevel = (level != null) ? level.intValue() : 1;

            String language = (String) httpSession.getAttribute("language");

            if (currentStep == null) {
                httpSession.setAttribute("currentStep", RegistrationStep.LANGUAGE_SELECTION);
                httpSession.setAttribute("level", 1);
                currentStep = RegistrationStep.LANGUAGE_SELECTION;
                currentLevel = 1;
            }

            switch (currentStep) {
                case LANGUAGE_SELECTION:
                    if (text.equalsIgnoreCase("1")) {
                        httpSession.setAttribute("language", "English");
                        response = "CON Please enter your First Name:";
                    } else if (text.equalsIgnoreCase("2")) {
                        httpSession.setAttribute("language", "French");
                        response = "CON Veuillez entrer votre prénom:";
                    } else {
                        // Invalid selection, show language selection menu again
                        response = "CON Invalid input. Select your preferred language:\n";
                        response += "1. English\n";
                        response += "2. French";
                    }
                    httpSession.setAttribute("currentStep", RegistrationStep.FIRST_NAME);
                    break;
                case FIRST_NAME:
                    // Your first name registration logic here
                    // Move to the next step (asking for Last Name)
                    httpSession.setAttribute("firstName", text);
                    httpSession.setAttribute("currentStep", RegistrationStep.LAST_NAME);
                    response = language.equalsIgnoreCase("French")
                            ? "CON Veuillez entrer votre nom de famille:"
                            : "CON Please enter your Last Name:";
                    break;
                case LAST_NAME:
                    // Your last name registration logic here
                    // Move to the next step (asking for National ID)
                    httpSession.setAttribute("lastName", text);
                    httpSession.setAttribute("currentStep", RegistrationStep.NATIONAL_ID);
                    response = language.equalsIgnoreCase("French")
                            ? "CON Veuillez entrer votre numéro d'identification nationale:"
                            : "CON Please enter your National ID:";
                    break;
                case NATIONAL_ID:
                    // Your national ID registration logic here
                    // Move to the next step (asking for Location)
                    httpSession.setAttribute("nationalId", text);
                    httpSession.setAttribute("currentStep", RegistrationStep.LOCATION);
                    response = language.equalsIgnoreCase("French")
                            ? "CON Veuillez entrer votre emplacement:"
                            : "CON Please enter your Location:";
                    break;
                case LOCATION:
                    // Your location registration logic here
                    // Move to the next step (asking for confirmation)
                    httpSession.setAttribute("location", text);
                    httpSession.setAttribute("currentStep", RegistrationStep.CONFIRMATION);
                    response = language.equalsIgnoreCase("French")
                            ? "CON Veuillez confirmer vos informations:\n"
                            : "CON Please confirm your information:\n";
                    response += "First Name: " + httpSession.getAttribute("firstName") + "\n";
                    response += "Last Name: " + httpSession.getAttribute("lastName") + "\n";
                    response += "National ID: " + httpSession.getAttribute("nationalId") + "\n";
                    response += "Location: " + text + "\n";
                    response += language.equalsIgnoreCase("French")
                            ? "Répondez avec 1 pour confirmer ou 2 pour annuler."
                            : "Reply with 1 to confirm or 2 to cancel.";
                    break;
                case CONFIRMATION:
                    // Your confirmation logic here
                    if (text.equals("1")) {
                        // Save the user information to the database
                        // Clear the session after successful registration
                        httpSession.removeAttribute("currentStep");
                        httpSession.removeAttribute("language");
                        httpSession.removeAttribute("firstName");
                        httpSession.removeAttribute("lastName");
                        httpSession.removeAttribute("nationalId");
                        httpSession.removeAttribute("location");

                        response = language.equalsIgnoreCase("French")
                                ? "END Inscription terminée. Vos informations ont été enregistrées."
                                : "END Registration completed. Your information has been saved.";
                    } else if (text.equals("2")) {
                        // If the user cancels, end the session
                        httpSession.setAttribute("currentStep", RegistrationStep.END);
                        response = language.equalsIgnoreCase("French")
                                ? "END Inscription annulée."
                                : "END Registration canceled.";
                    } else {
                        // If the user enters an invalid response, prompt again for confirmation
                        response = language.equalsIgnoreCase("French")
                                ? "Réponse invalide. Répondez avec 1 pour confirmer ou 2 pour annuler."
                                : " Invalid input. Reply with 1 to confirm or 2 to cancel.";
                    }
                    break;
                case END:
                    response = language.equalsIgnoreCase("French")
                            ? "END Merci de vous être inscrit !"
                            : "END Thank you for registering!";
                    break;
            }

            // Update the user's level in the session for the next interaction
            currentLevel++;
            httpSession.setAttribute("level", currentLevel);
        }

        return response;
    }
}
